# Telegram setup notes for Hermes

Use this as the condensed checklist when setting up Hermes on Telegram.

## Recommended setup flow
1. In Telegram, open @BotFather and run /newbot.
2. Pick a display name and a unique username ending in `bot`.
3. Save the bot token BotFather returns.
4. Get your numeric Telegram user ID from @userinfobot (recommended) or @get_id_bot.
5. Run `hermes gateway setup` and choose Telegram when prompted.
6. Paste the bot token and allowed user ID(s).
7. Start the gateway with `hermes gateway` and verify the bot responds.

## Manual config
Add to `~/.hermes/.env`:

```env
TELEGRAM_BOT_TOKEN=123456...
TELEGRAM_ALLOWED_USERS=123456789
```

For groups, add the group chat ID allowlist as needed:

```env
TELEGRAM_GROUP_ALLOWED_CHATS=-1001234567890
```

## Important Telegram quirks
- Hermes uses numeric Telegram user IDs, not @usernames, for access control.
- Telegram bot privacy mode is ON by default and blocks ordinary group messages.
- To let Hermes observe ordinary group chatter, disable privacy mode in BotFather or promote the bot to group admin.
- After changing privacy mode, remove and re-add the bot to the group so Telegram refreshes the state.

## Group usage patterns
- Use `allowed_chats` / `group_allowed_chats` to restrict where the bot may operate.
- Use `require_mention: true` when you want the bot to respond only when directly addressed.
- Use `observe_unmentioned_group_messages: true` if you want Hermes to retain group chatter as shared context without auto-replying.

## Slash-command access control
- `allow_from` controls who can chat with the bot.
- `allow_admin_from` grants full slash-command access.
- `user_allowed_commands` limits non-admin users to a small command set.
- `/whoami` is the easiest way to confirm scope and command access.

## Webhook / local Bot API notes
- Webhook mode uses `TELEGRAM_WEBHOOK_URL` and `TELEGRAM_WEBHOOK_SECRET`.
- Large-file support can use a local telegram-bot-api server with `base_url`, `base_file_url`, and `local_mode: true`.
- If you use a local Bot API server, verify it with `getMe` against the local base URL before pointing Hermes at it.
