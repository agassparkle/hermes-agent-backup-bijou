---
name: home-server-service-management
description: Manage services on a home Ubuntu server (qBittorrent, Foundry VTT, Home Assistant, etc.) — start/stop, configure, troubleshoot headless operation.
category: devops
---

# Home Server Service Management

Manage long-running services on the user's Ubuntu home server. The server runs multiple self-hosted applications (Foundry VTT, Home Assistant, qBittorrent, etc.) behind Caddy reverse proxy.

## Core Principles

1. **Check config first** — Always read the service's config file before overriding settings (ports, paths, auth). The config file is the source of truth.
2. **Don't install unless asked** — Never run `apt install` or similar unless the user explicitly requests it. Most services are already installed.
3. **Respect headless requirements** — Qt-based apps (qBittorrent, etc.) need `QT_QPA_PLATFORM=offscreen` to run without a display.
4. **Use existing process management** — Prefer systemd services when they exist. If not, background processes with `notify_on_complete=false` for daemons.

## qBittorrent Specifics

- Binary: `/usr/bin/qbittorrent` (GUI version, works headless with offscreen)
- Config: `~/.config/qBittorrent/qBittorrent.conf`
- WebUI port: read from `WebUI\Port` in config (default 8080)
- Headless launch: `QT_QPA_PLATFORM=offscreen qbittorrent --no-splash &`
- Do NOT pass `--webui-port` unless user explicitly wants to override config

## Foundry VTT Specifics

- Two instances: localhost:30000 and localhost:30001
- Caddy reverse proxy in front
- Managed via systemd (check `systemctl status foundry*`)

## Home Assistant Specifics

- Long-lived token for API access
- Entity IDs stored in memory (e.g., `media_player.android_tv_192_168_1_62` for Shield)
- REST API via `ha_*` tools

## Common Pitfalls

| Pitfall | Fix |
|---------|-----|
| Qt app fails with "could not connect to display" | Set `QT_QPA_PLATFORM=offscreen` |
| Port mismatch | Read config file first (`grep -i port ~/.config/qBittorrent/qBittorrent.conf`) |
| Killing wrong process | Use `pgrep -f` to verify PIDs, check listening ports with `ss -tlnp \| grep qbittorrent` |
| Assuming service isn't installed | Check `which <binary>` and `apt list --installed \| grep <name>` first |

## Verification Steps

After starting any service:
1. `pgrep -f <service>` — confirm process running
2. `ss -tlnp \| grep <port>` — confirm port listening
3. Test endpoint if applicable (curl WebUI, etc.)